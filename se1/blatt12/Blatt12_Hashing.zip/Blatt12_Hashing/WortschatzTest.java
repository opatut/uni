/**
 * Diese Klasse testet den Wortschatz.
 *
 * @author Fredrik Winkler
 * @version Januar 2012
 */
public class WortschatzTest extends junit.framework.TestCase
{
    private final Wortschatz _schatz;
    
    /**
     * Jede Testmethode arbeitet auf einem frisch erzeugten Exemplar.
     */
    public WortschatzTest()
    {
        _schatz = new HashWortschatz(new Delegation(), 10);
    }
    
    /**
     * Stellt sicher, dass ein neuer Wortschatz leer ist.
     */
    public void testNeuerWortschatzIstLeer()
    {
        assertEquals(0, _schatz.anzahlWoerter());
    }

    /**
     * 
     */
    public void testHinzugefuegtesWortIstEnthalten()
    {
    }
    
    /**
     * 
     */
    public void testEntferntesWortIstNichtEnthalten()
    {
    }
    
    /**
     * 
     */
    public void testNichtHinzugefuegtesWortIstNichtEnthalten()
    {
    }
    
    /**
     * 
     */
    public void testDuplikateWerdenNichtHinzugefuegt()
    {
    }
    
    /**
     * 
     */
    public void testEntfernenNichtEnthaltenerWoerterBewirktNichts()
    {
    }
}
